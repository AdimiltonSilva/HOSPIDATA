This directory contains documentation specific to this version. More general
documentation about the psqlODBC project, and on how to use the driver is
available at the psqlODBC website, at https://odbc.postgresql.org/.
